﻿Module Module1
    Public Sub Main()
        Form1.ShowDialog()
    End Sub

    Class Form2
        Inherits Form
    End Class

End Module

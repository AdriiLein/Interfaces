﻿Public Class Form1

    Private Sub Form1_FormClosed(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosedEventArgs) Handles Me.FormClosed
        Me.Hide()
        Dim form2 = New Form2
        form2.Text = "form2"
        form2.ShowDialog()
    End Sub

    Private Sub Form1_MouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Me.MouseClick
        Me.ClientSize = New System.Drawing.Size(600, 200)
    End Sub

    Private Sub Form1_MouseDoubleClick(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles Me.MouseDoubleClick
        Me.WindowState = FormWindowState.Maximized
    End Sub
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Me.BackColor = System.Drawing.Color.Gray
    End Sub
    Private Sub Click_botones(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click, Button2.Click

    End Sub
    Private Sub MiFormulario_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.Label1.Text = "Hola soy Label 1"
    End Sub

    Private Sub CheckBox1_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles Checkbox1.Click
        Me.BackColor = System.Drawing.Color.Red
        reset()
        CheckBox2.CheckState = False
        CheckBox3.CheckState = False
    End Sub

    Private Sub CheckBox2_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles CheckBox2.Click
        Me.BackColor = System.Drawing.Color.Yellow
        reset()
        Checkbox1.CheckState = False
        CheckBox3.CheckState = False
    End Sub

    Private Sub CheckBox3_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles CheckBox3.Click
        Me.BackColor = System.Drawing.Color.Green
        reset()
        CheckBox2.CheckState = False
        Checkbox1.CheckState = False
    End Sub
    Sub reset()
        If (Checkbox1.CheckState = CheckState.Unchecked And CheckBox2.CheckState = CheckState.Unchecked And CheckBox3.CheckState = CheckState.Unchecked) Then
            Me.BackColor = Color.LightGray
        End If
    End Sub
    Private Sub botonVacio(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click, Button3.Click
        MsgBox("boton sin contenido")
    End Sub

End Class

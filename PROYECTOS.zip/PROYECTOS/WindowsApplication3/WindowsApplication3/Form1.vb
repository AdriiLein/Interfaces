﻿Public Class Form1

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load


    End Sub

    Private Sub Click_Ejecutar(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        If String.IsNullOrEmpty(TextBox1.Text) OrElse String.IsNullOrEmpty(TextBox2.Text) Then
            Me.Label3.Text = "Introduce los datos de entrada"
            Me.Label3.ForeColor = System.Drawing.Color.Red
        End If

        'If TextBox2.Text = String.Empty Then
        'Me.Label3.Text = "Introduce los datos de entrada"
        'Me.Label3.ForeColor = System.Drawing.Color.Red
        'End If

    End Sub


    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged
        Dim Posicion As String
        Posicion = "primera"
        esNumerico(TextBox1.Text, Posicion)
    End Sub

    Private Sub TextBox2_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox2.TextChanged
        Dim Posicion As String
        Posicion = "segunda"
        esNumerico(TextBox2.Text, Posicion)
        Reset()
    End Sub

    Sub esNumerico(ByVal Textbox As String, ByVal Posicion As String)
        If IsNumeric(Textbox) = True Then
            estaVacio()
        Else
            Me.Label3.Text = "La " & Posicion & " entrada no es numerica"
            Me.Label3.ForeColor = System.Drawing.Color.Red
        End If
    End Sub

    Sub estaVacio()
        If String.IsNullOrEmpty(TextBox1.Text) Then
            Me.Label3.Text = "La primera entrada esta vacia"
            Me.Label3.ForeColor = System.Drawing.Color.Red
        End If
        If String.IsNullOrEmpty(TextBox2.Text) Then
            Me.Label3.Text = "La segunda entrada esta vacia"
            Me.Label3.ForeColor = System.Drawing.Color.Red
        End If
    End Sub

    Sub reset()
    End Sub

End Class
